^ [[Sort Subject]] |

#### SUBJECT NUMBER | SUBJECT NAME
```dataview
list from #whereID and !"Sort" and !"Template"
```