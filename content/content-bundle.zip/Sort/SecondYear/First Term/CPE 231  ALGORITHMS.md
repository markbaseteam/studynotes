^ [[Home Page]] / [[Sort Subject]] |

#### CPE 231 | ALGORITHMS
```dataview
list from #cpe231 and !"Sort" and !"Template"
```