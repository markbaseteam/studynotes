^ [[Home Page]] / [[Sort Subject]] |

#### MTH 234 | LINEAR ALGEBRA 
```dataview
list from #mth234 and !"Sort" and !"Template"
```