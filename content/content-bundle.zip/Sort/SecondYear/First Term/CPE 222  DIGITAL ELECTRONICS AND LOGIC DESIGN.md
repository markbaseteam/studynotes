^ [[Home Page]] / [[Sort Subject]] |

#### CPE 222 | DIGITAL ELECTRONICS AND LOGIC DESIGN
```dataview
list from #cpe222 and !"Sort" and !"Template"
```