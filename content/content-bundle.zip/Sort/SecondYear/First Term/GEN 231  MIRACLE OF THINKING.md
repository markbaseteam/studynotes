^ [[Home Page]] / [[Sort Subject]] |

#### GEN 231 | MIRACLE OF THINKING
```dataview
list from #gen231 and !"Sort" and !"Template"
```