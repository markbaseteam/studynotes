^ [[Home Page]] |

# Sort subject

#### status: #sort

detail:: #SecondYear #FirstTerm #KMUTT

---
## Second years | First Term
```dataview
table
from "Sort/SecondYear/First Term"
where file.name != "Sort Subject"
```

## Second years | Second Term
```dataview
table
from "Sort/SecondYear/Second Term"
where file.name != "Sort Subject"
```
