^ [[Home Page]] | 

---

### Summary
```dataview
table Summary as "Summary"
from #classnotes and #status/todo and !"Template"
where file.name != "Course notes"
sort filename.ctime desc
```

### Fill in
```dataview
table file.ctime as "Creation time"
from  #fillin
where file.name != "Stude notes"
sort file.ctime desc
```
